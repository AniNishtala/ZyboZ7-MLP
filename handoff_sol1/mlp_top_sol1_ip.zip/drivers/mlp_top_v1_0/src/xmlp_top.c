// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmlp_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMlp_top_CfgInitialize(XMlp_top *InstancePtr, XMlp_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMlp_top_Start(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMlp_top_IsDone(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMlp_top_IsIdle(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMlp_top_IsReady(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMlp_top_EnableAutoRestart(XMlp_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMlp_top_DisableAutoRestart(XMlp_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XMlp_top_Get_output_r(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_OUTPUT_R_DATA);
    return Data;
}

u32 XMlp_top_Get_output_r_vld(XMlp_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_OUTPUT_R_CTRL);
    return Data & 0x1;
}

u32 XMlp_top_Get_img_bits_BaseAddress(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE);
}

u32 XMlp_top_Get_img_bits_HighAddress(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH);
}

u32 XMlp_top_Get_img_bits_TotalBytes(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH - XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + 1);
}

u32 XMlp_top_Get_img_bits_BitWidth(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMLP_TOP_CONTROL_WIDTH_IMG_BITS;
}

u32 XMlp_top_Get_img_bits_Depth(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMLP_TOP_CONTROL_DEPTH_IMG_BITS;
}

u32 XMlp_top_Write_img_bits_Words(XMlp_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH - XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XMlp_top_Read_img_bits_Words(XMlp_top *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH - XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + (offset + i)*4);
    }
    return length;
}

u32 XMlp_top_Write_img_bits_Bytes(XMlp_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH - XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XMlp_top_Read_img_bits_Bytes(XMlp_top *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XMLP_TOP_CONTROL_ADDR_IMG_BITS_HIGH - XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XMLP_TOP_CONTROL_ADDR_IMG_BITS_BASE + offset + i);
    }
    return length;
}

void XMlp_top_InterruptGlobalEnable(XMlp_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_GIE, 1);
}

void XMlp_top_InterruptGlobalDisable(XMlp_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_GIE, 0);
}

void XMlp_top_InterruptEnable(XMlp_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_IER);
    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XMlp_top_InterruptDisable(XMlp_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_IER);
    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMlp_top_InterruptClear(XMlp_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMlp_top_WriteReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XMlp_top_InterruptGetEnabled(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_IER);
}

u32 XMlp_top_InterruptGetStatus(XMlp_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMlp_top_ReadReg(InstancePtr->Control_BaseAddress, XMLP_TOP_CONTROL_ADDR_ISR);
}

